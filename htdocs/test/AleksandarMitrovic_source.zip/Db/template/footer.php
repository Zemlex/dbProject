
	<footer class = "section">
		<div class = "center grey-text"> enjoy your stay </div>
	</footer>
</body>
